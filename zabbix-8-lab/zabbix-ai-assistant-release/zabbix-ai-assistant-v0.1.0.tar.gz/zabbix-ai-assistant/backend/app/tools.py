import json
import time
import uuid
from datetime import datetime, timedelta, timezone

from app.db import db
from app.mcp import mcp_client
from app.zabbix_api import zabbix_api


LOCAL_TOOLS = [
    {
        "name": "zabbix_host_create",
        "description": "Create a Zabbix host after validating existing host groups and templates. Use only when the user explicitly asks to create/onboard a host.",
        "parameters": {
            "type": "object",
            "properties": {
                "host": {"type": "string"},
                "name": {"type": "string"},
                "group_names": {"type": "array", "items": {"type": "string"}},
                "template_names": {"type": "array", "items": {"type": "string"}},
                "interfaces": {"type": "array", "items": {"type": "object"}},
                "tags": {"type": "array", "items": {"type": "object"}},
                "macros": {"type": "array", "items": {"type": "object"}},
                "proxyid": {"type": "string"},
                "status": {"type": "integer"}
            },
            "required": ["host", "group_names", "interfaces"],
            "additionalProperties": False,
        },
        "read_only": False,
        "source": "api",
    },
    {
        "name": "zabbix_host_update",
        "description": "Update basic attributes of an existing Zabbix host by hostid.",
        "parameters": {
            "type": "object",
            "properties": {
                "hostid": {"type": "string"},
                "host": {"type": "string"},
                "name": {"type": "string"},
                "status": {"type": "integer"},
                "proxyid": {"type": "string"},
                "tags": {"type": "array", "items": {"type": "object"}},
                "macros": {"type": "array", "items": {"type": "object"}}
            },
            "required": ["hostid"],
            "additionalProperties": False,
        },
        "read_only": False,
        "source": "api",
    },
]


def default_mode(tool: dict) -> str:
    if tool.get("read_only", False):
        return "auto"
    return "confirm"


def get_policy(tool_name: str, tool: dict) -> str:
    with db() as conn:
        row = conn.execute("SELECT mode FROM tool_policy WHERE tool_name=%s", (tool_name,)).fetchone()
    return row["mode"] if row else default_mode(tool)


async def available_tools() -> list[dict]:
    mcp_tools = await mcp_client.tools_list()
    normalized = []
    for t in mcp_tools:
        annotations = t.get("annotations", {}) or {}
        normalized.append({
            "name": t["name"],
            "description": t.get("description", ""),
            "parameters": t.get("inputSchema", {"type": "object"}),
            "read_only": bool(annotations.get("readOnlyHint", False)),
            "source": "mcp",
        })
    normalized.extend(LOCAL_TOOLS)
    return normalized


async def create_pending_action(user: dict, interaction_id: str, tool: dict, arguments: dict) -> dict:
    action_id = str(uuid.uuid4())
    preview = {"tool": tool["name"], "source": tool["source"], "arguments": arguments}
    expires = datetime.now(timezone.utc) + timedelta(minutes=5)
    with db() as conn:
        conn.execute(
            """
            INSERT INTO pending_actions(action_id, interaction_id, zabbix_userid, zabbix_username, source, tool_name, arguments_json, preview_json, expires_at)
            VALUES (%s,%s,%s,%s,%s,%s,%s::jsonb,%s::jsonb,%s)
            """,
            (action_id, interaction_id, str(user["userid"]), user["username"], tool["source"], tool["name"], json.dumps(arguments), json.dumps(preview), expires),
        )
        conn.commit()
    return {"action_id": action_id, "expires_at": expires.isoformat(), **preview}


async def execute_tool(tool: dict, arguments: dict):
    started = time.perf_counter()
    if tool["source"] == "mcp":
        result, duration_ms = await mcp_client.call_tool(tool["name"], arguments)
        return result, duration_ms
    if tool["name"] == "zabbix_host_create":
        result = await zabbix_api.host_create(arguments)
    elif tool["name"] == "zabbix_host_update":
        result = await zabbix_api.host_update(arguments)
    else:
        raise RuntimeError(f"Unknown local tool: {tool['name']}")
    return result, int((time.perf_counter() - started) * 1000)
