from pydantic_settings import BaseSettings, SettingsConfigDict


class Settings(BaseSettings):
    model_config = SettingsConfigDict(env_file=".env", case_sensitive=False)

    app_name: str = "Zabbix AI Assistant"
    app_env: str = "production"
    log_level: str = "INFO"

    database_host: str
    database_port: int = 5432
    database_name: str = "zabbix_ai"
    database_user: str = "zabbix_ai"
    database_password: str

    mcp_url: str = "http://zabbix-mcp-server:8443/mcp"
    zabbix_api_url: str = "http://zabbix-web:8080/api_jsonrpc.php"

    ai_master_key: str
    ai_module_key: str

    conversation_retention_days: int = 30
    metadata_retention_days: int = 365
    audit_retention_days: int = 365
    max_tool_calls: int = 8
    request_timeout_seconds: int = 30


settings = Settings()
