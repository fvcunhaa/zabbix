import httpx

from app.providers.base import BaseProvider, ProviderError


class AnthropicProvider(BaseProvider):
    def __init__(self, api_key: str):
        self.api_key = api_key
        self.base_url = "https://api.anthropic.com/v1"

    async def run(self, *, model: str, messages: list[dict], tools: list[dict], max_tool_rounds: int, tool_executor):
        headers = {
            "x-api-key": self.api_key,
            "anthropic-version": "2023-06-01",
            "content-type": "application/json",
        }
        anth_tools = [
            {"name": t["name"], "description": t.get("description", ""), "input_schema": t.get("parameters", {"type": "object"})}
            for t in tools
        ]
        convo = [{"role": m["role"], "content": m["content"]} for m in messages]
        total_in = total_out = 0

        async with httpx.AsyncClient(timeout=90.0) as client:
            for _ in range(max_tool_rounds + 1):
                payload = {"model": model, "max_tokens": 4096, "messages": convo, "tools": anth_tools}
                response = await client.post(f"{self.base_url}/messages", headers=headers, json=payload)
                if response.status_code >= 400:
                    raise ProviderError(f"Anthropic error {response.status_code}: {response.text[:500]}")
                data = response.json()
                usage = data.get("usage", {})
                total_in += int(usage.get("input_tokens", 0) or 0)
                total_out += int(usage.get("output_tokens", 0) or 0)
                tool_uses = [b for b in data.get("content", []) if b.get("type") == "tool_use"]
                if not tool_uses:
                    text = "\n".join(b.get("text", "") for b in data.get("content", []) if b.get("type") == "text")
                    return {"text": text, "input_tokens": total_in, "output_tokens": total_out}

                convo.append({"role": "assistant", "content": data.get("content", [])})
                results = []
                for block in tool_uses:
                    result = await tool_executor(block.get("name", ""), block.get("input", {}) or {})
                    if result.get("requires_confirmation"):
                        return {
                            "text": result.get("message", "Ação requer confirmação."),
                            "input_tokens": total_in,
                            "output_tokens": total_out,
                            "pending_action": result.get("pending_action"),
                        }
                    results.append({"type": "tool_result", "tool_use_id": block.get("id"), "content": str(result)})
                convo.append({"role": "user", "content": results})

        raise ProviderError("Maximum tool rounds reached")
