import json

import httpx

from app.config import settings
from app.providers.base import BaseProvider, ProviderError


class OpenAIProvider(BaseProvider):
    def __init__(self, api_key: str):
        self.api_key = api_key
        self.base_url = "https://api.openai.com/v1"

    async def run(self, *, model: str, messages: list[dict], tools: list[dict], max_tool_rounds: int, tool_executor):
        headers = {"Authorization": f"Bearer {self.api_key}", "Content-Type": "application/json"}
        input_items = [{"role": m["role"], "content": m["content"]} for m in messages]
        previous_response_id = None
        total_in = total_out = 0

        async with httpx.AsyncClient(timeout=90.0) as client:
            for _ in range(max_tool_rounds + 1):
                payload = {
                    "model": model,
                    "input": input_items,
                    "tools": tools,
                    "tool_choice": "auto",
                }
                if previous_response_id:
                    payload["previous_response_id"] = previous_response_id
                response = await client.post(f"{self.base_url}/responses", headers=headers, json=payload)
                if response.status_code >= 400:
                    raise ProviderError(f"OpenAI error {response.status_code}: {response.text[:500]}")
                data = response.json()
                previous_response_id = data.get("id")
                usage = data.get("usage", {})
                total_in += int(usage.get("input_tokens", 0) or 0)
                total_out += int(usage.get("output_tokens", 0) or 0)

                calls = [item for item in data.get("output", []) if item.get("type") == "function_call"]
                if not calls:
                    text = data.get("output_text")
                    if not text:
                        chunks = []
                        for item in data.get("output", []):
                            for content in item.get("content", []) or []:
                                if content.get("type") == "output_text":
                                    chunks.append(content.get("text", ""))
                        text = "\n".join(chunks)
                    return {"text": text or "", "input_tokens": total_in, "output_tokens": total_out}

                input_items = []
                for call in calls:
                    try:
                        arguments = json.loads(call.get("arguments") or "{}")
                    except json.JSONDecodeError:
                        arguments = {}
                    result = await tool_executor(call.get("name", ""), arguments)
                    if result.get("requires_confirmation"):
                        return {
                            "text": result.get("message", "Ação requer confirmação."),
                            "input_tokens": total_in,
                            "output_tokens": total_out,
                            "pending_action": result.get("pending_action"),
                        }
                    input_items.append({
                        "type": "function_call_output",
                        "call_id": call.get("call_id"),
                        "output": json.dumps(result, ensure_ascii=False),
                    })

        raise ProviderError("Maximum tool rounds reached")
