from abc import ABC, abstractmethod


class ProviderError(RuntimeError):
    pass


class BaseProvider(ABC):
    @abstractmethod
    async def run(self, *, model: str, messages: list[dict], tools: list[dict], max_tool_rounds: int, tool_executor):
        raise NotImplementedError
