CREATE TABLE IF NOT EXISTS settings (
    setting_key TEXT PRIMARY KEY,
    setting_value TEXT NOT NULL,
    encrypted BOOLEAN NOT NULL DEFAULT FALSE,
    updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE TABLE IF NOT EXISTS interactions (
    interaction_id UUID PRIMARY KEY,
    zabbix_userid TEXT NOT NULL,
    zabbix_username TEXT NOT NULL,
    provider TEXT,
    model TEXT,
    prompt_text TEXT,
    response_text TEXT,
    prompt_tokens BIGINT NOT NULL DEFAULT 0,
    completion_tokens BIGINT NOT NULL DEFAULT 0,
    total_tokens BIGINT NOT NULL DEFAULT 0,
    estimated_cost_usd NUMERIC(18,8) NOT NULL DEFAULT 0,
    duration_ms BIGINT NOT NULL DEFAULT 0,
    status TEXT NOT NULL DEFAULT 'ok',
    created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE INDEX IF NOT EXISTS idx_interactions_created_at ON interactions(created_at);
CREATE INDEX IF NOT EXISTS idx_interactions_user ON interactions(zabbix_userid, created_at);

CREATE TABLE IF NOT EXISTS tool_calls (
    id BIGSERIAL PRIMARY KEY,
    interaction_id UUID REFERENCES interactions(interaction_id) ON DELETE CASCADE,
    source TEXT NOT NULL,
    tool_name TEXT NOT NULL,
    arguments_json JSONB,
    result_status TEXT NOT NULL,
    read_only BOOLEAN NOT NULL DEFAULT TRUE,
    duration_ms BIGINT NOT NULL DEFAULT 0,
    created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE INDEX IF NOT EXISTS idx_tool_calls_created_at ON tool_calls(created_at);
CREATE INDEX IF NOT EXISTS idx_tool_calls_tool ON tool_calls(tool_name, created_at);

CREATE TABLE IF NOT EXISTS pending_actions (
    action_id UUID PRIMARY KEY,
    interaction_id UUID REFERENCES interactions(interaction_id) ON DELETE CASCADE,
    zabbix_userid TEXT NOT NULL,
    zabbix_username TEXT NOT NULL,
    source TEXT NOT NULL,
    tool_name TEXT NOT NULL,
    arguments_json JSONB NOT NULL,
    preview_json JSONB NOT NULL,
    status TEXT NOT NULL DEFAULT 'pending',
    created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    expires_at TIMESTAMPTZ NOT NULL
);

CREATE TABLE IF NOT EXISTS audit_log (
    id BIGSERIAL PRIMARY KEY,
    interaction_id UUID,
    zabbix_userid TEXT NOT NULL,
    zabbix_username TEXT NOT NULL,
    event_type TEXT NOT NULL,
    operation TEXT,
    details_json JSONB,
    result_status TEXT,
    created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE INDEX IF NOT EXISTS idx_audit_created_at ON audit_log(created_at);
CREATE INDEX IF NOT EXISTS idx_audit_user ON audit_log(zabbix_userid, created_at);

CREATE TABLE IF NOT EXISTS tool_policy (
    tool_name TEXT PRIMARY KEY,
    mode TEXT NOT NULL CHECK (mode IN ('auto', 'confirm', 'disabled')),
    updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE TABLE IF NOT EXISTS model_pricing (
    provider TEXT NOT NULL,
    model TEXT NOT NULL,
    input_per_million NUMERIC(18,8) NOT NULL DEFAULT 0,
    output_per_million NUMERIC(18,8) NOT NULL DEFAULT 0,
    updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    PRIMARY KEY(provider, model)
);

INSERT INTO tool_policy(tool_name, mode) VALUES
    ('problem_acknowledge', 'confirm'),
    ('problem_annotate', 'confirm'),
    ('problem_change_severity', 'confirm'),
    ('problem_suppress', 'confirm'),
    ('problem_unsuppress', 'confirm'),
    ('problem_close', 'confirm'),
    ('maintenance_create', 'confirm'),
    ('maintenance_update', 'confirm'),
    ('maintenance_delete', 'confirm'),
    ('zabbix_host_create', 'confirm'),
    ('zabbix_host_update', 'confirm'),
    ('zabbix_host_delete', 'disabled')
ON CONFLICT (tool_name) DO NOTHING;
